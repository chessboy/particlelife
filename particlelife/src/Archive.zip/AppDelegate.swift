//
//  AppDelegate.swift
//  particlelife
//
//  Created by Rob Silverman on 2/14/25.
//

import Cocoa
import SwiftUI

@main
class AppDelegate: NSObject, NSApplicationDelegate {
    var window: NSWindow?

    func applicationDidFinishLaunching(_ notification: Notification) {
       
    }
}
