//
//  SettingsView.swift
//  particlelife
//
//  Created by Rob Silverman on 2/14/25.
//

import SwiftUI

struct SimulationSettingsView: View {
    @ObservedObject var particleSystem = ParticleSystem.shared
    @ObservedObject var settings = SimulationSettings.shared
    @State private var interactionMatrix: [[Float]] = ParticleSystem.shared.interactionMatrix
    @State private var speciesColors: [Color] = ParticleSystem.shared.speciesColors

    var body: some View {
        VStack {
            Text("Simulation Settings")
                .font(.headline)
                .foregroundColor(.white)
                .padding(.bottom, 5)
            
            MatrixView(interactionMatrix: interactionMatrix)

            Slider(value: $settings.maxDistance, in: SimulationSettings.maxDistanceMin...SimulationSettings.maxDistanceMax, step: 0.01) {
                Text("Max Distance: \(settings.maxDistance, specifier: "%.2f")")
            }

            Slider(value: $settings.minDistance, in: SimulationSettings.minDistanceMin...SimulationSettings.minDistanceMax, step: 0.01) {
                Text("Min Distance: \(settings.minDistance, specifier: "%.2f")")
            }

            Slider(value: $settings.beta, in: SimulationSettings.betaMin...SimulationSettings.betaMax, step: 0.01) {
                Text("Beta: \(settings.beta, specifier: "%.2f")")
            }

            Slider(value: $settings.friction, in: SimulationSettings.frictionMin...SimulationSettings.frictionMax, step: 0.001) {
                Text("Friction: \(settings.friction, specifier: "%.3f")")
            }

            Slider(value: $settings.repulsionStrength, in: SimulationSettings.repulsionStrengthMin...SimulationSettings.repulsionStrengthMax, step: 0.01) {
                Text("Repulsion Strength: \(settings.repulsionStrength, specifier: "%.2f")")
            }
            
            Divider()
                .background(Color.white.opacity(0.5))
                .padding(.vertical, 5)
            
            Button(action: {
                settings.resetToDefaults()  // ✅ Reset physics settings to defaults
            }) {
                Text("Reset to Defaults")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue.opacity(0.7))  // ✅ Semi-transparent blue
                    .compositingGroup()  // ✅ Reduces GPU redraws
                    .drawingGroup()  // ✅ Renders UI as a single texture to reduce SwiftUI overhead
                    .cornerRadius(10)
            }
            .padding(.top, 10)
        }
        .padding()
        .background(Color.black.opacity(0.5))
        .cornerRadius(10)
        .shadow(radius: 5)
        .onReceive(NotificationCenter.default.publisher(for: .resetSimulation)) { _ in
            interactionMatrix = ParticleSystem.shared.interactionMatrix
            speciesColors = ParticleSystem.shared.speciesColors
        }
    }
}

//#Preview {
//    SimulationSettingsView()
//        .frame(width: 300, height: 250)  // ✅ Set a reasonable preview size
//        .background(Color.gray.opacity(0.3))  // ✅ Helps visualize transparency in the preview
//}
